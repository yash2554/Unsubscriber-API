import re
import logging
import time
from datetime import datetime
from selenium import webdriver
from django.shortcuts import render,HttpResponse
from algorithm import view_url

def home(request):
	#return render(request,'unregister/index.php')
	request_url = request.build_absolute_uri()
	urls = re.search('\/\?url\=(.*)',request_url).group(1)
	if urls != '':
		date = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
		LOG_FILENAME = 'url_unsubscriber.log'
		logging.basicConfig(filename=LOG_FILENAME,level=logging.DEBUG)
		logging.debug(' ' + date + ' ' + urls + ' ' + 'URL_parsed_correctly')

		processed = view_url(urls)

		if processed == 0:
			return render(request,'unregister/index.php')
		else:
			return HttpResponse('Can not parse the URL :: ' + urls)
	else:
		urls = 'ERROR IN REQUEST'
		return HttpResponse(urls)
