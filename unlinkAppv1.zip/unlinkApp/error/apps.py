from django.apps import AppConfig


class ErrorConfig(AppConfig):
    name = 'error'
