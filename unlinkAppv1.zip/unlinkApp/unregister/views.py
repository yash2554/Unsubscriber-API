import re
import logging
from datetime import datetime
from django.shortcuts import  render,HttpResponse
from unregister.checkUrl import checkReqUrl


def index(request):
   #return HttpResponse("<h1>Unregister index</h1>")
   return checkReqUrl(request)
