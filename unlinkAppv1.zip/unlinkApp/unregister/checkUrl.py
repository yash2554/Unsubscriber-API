import re
import logging
from datetime import datetime
from django.shortcuts import  render,HttpResponse
from unregister.browserAuto import processReqUrl


def checkReqUrl(request):
   #return HttpResponse("<h1>checkUrl index</h1>")
   return processReqUrl(request)
   request_url = request.build_absolute_uri()
   urls = re.search('\/\?url\=(.*)', request_url).group(1)
   if urls != '':
      date = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
      LOG_FILENAME = 'logs/url_unsubscriber.log'
      logging.basicConfig(filename=LOG_FILENAME, level=logging.DEBUG)
      logging.debug(' ' + date + ' ' + urls + ' ' + 'URL_parsed_correctly')

      processed = processReqUrl(urls)

      if processed == 0:
         return render(request, 'unregister/index.php')
      else:
         return HttpResponse('Can not parse the URL :: ' + urls)
   else:
      urls = 'ERROR IN REQUEST'
      return HttpResponse(urls)
