from selenium.common.exceptions import NoAlertPresentException
from selenium.common.exceptions import NoSuchElementException
from django.shortcuts import render, HttpResponse
import requests
from bs4 import BeautifulSoup
import urllib
import logging
from datetime import datetime
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
import time
from unregister.extractUrl import extractReqUrl


def processReqUrl(urls):
    return HttpResponse("<h1>browserAuto index</h1>")
    LOG_FILENAME = 'logs/url_unsubscriber.log'
    logging.basicConfig(filename=LOG_FILENAME, level=logging.DEBUG)
    date = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    snap_name = 'snapshots/snapshot-' + datetime.now().strftime('%Y%m%d%H%M%S') + '.png'
    processed = 1

    browser = webdriver.Firefox()
    extractReqUrl(urls)
    browser.get(urls)
    time.sleep(2)

    try:
        browser.find_elements_by_xpath("//*[contains(text(), 'Thank you')]")
        processed = 0
    except NoSuchElementException:
        pass

    try:
        browser.find_element_by_xpath("//input[@type='submit']").send_keys(Keys.RETURN)
        processed = 0
    except NoSuchElementException:
        pass

    try:
        browser.find_element_by_xpath("//button[@type='submit']").send_keys(Keys.RETURN)
        processed = 0
    except NoSuchElementException:
        pass

    try:
        browser.find_element_by_xpath("//input[@type='button']").send_keys(Keys.RETURN)
        processed = 0
    except NoSuchElementException:
        pass

    try:
        browser.switch_to_alert().accept()
        processed = 0
    except NoAlertPresentException:
        pass

    logging.info(' ' + date + ' ' + urls + ' ' + 'URL_simulated_successfully')
    time.sleep(5)
    browser.save_screenshot(snap_name)
    browser.close()

    return processed;


def extractReqUrl(urls):
    page = requests.get(urls)
    if page.status_code != 200:
        return 0
    else:
        soup = BeautifulSoup(page.content, 'html.parser')
        print(soup.prettify())
        list(soup.children)
