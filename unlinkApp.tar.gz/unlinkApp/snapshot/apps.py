from django.apps import AppConfig


class SnapshotConfig(AppConfig):
    name = 'snapshot'
