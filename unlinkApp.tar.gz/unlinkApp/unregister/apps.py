from django.apps import AppConfig


class UnregisterConfig(AppConfig):
    name = 'unregister'
