from django.http import HttpResponse
import urllib2
from BeautifulSoup import BeautifulSoup

def index(request):
    page = urllib2.urlopen('https://www.google.com').read()
    soup = BeautifulSoup(page)
    soup.prettify()
    for anchor in soup.findAll('a', href=True):
        print anchor['href']
    return HttpResponse(soup.prettify())
    #return HttpResponse("<h1>unregister index</h1>")