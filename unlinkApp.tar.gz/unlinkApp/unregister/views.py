import re
import logging
from datetime import datetime
from django.shortcuts import  render,HttpResponse
from unregister.checkUrl import check


def index(request):
   return check(request)
