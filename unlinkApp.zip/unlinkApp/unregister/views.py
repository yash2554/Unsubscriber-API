from unregister.browserAutomation import processUrl
def index(request):
      return processUrl(request)
