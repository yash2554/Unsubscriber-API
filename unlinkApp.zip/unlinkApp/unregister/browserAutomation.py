from selenium.common.exceptions import NoAlertPresentException
from selenium.common.exceptions import NoSuchElementException
from django.shortcuts import render, HttpResponse
import requests
from bs4 import BeautifulSoup
import urllib
import logging
from datetime import datetime
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
import time
import re
import logging
from datetime import datetime

LOG_FILENAME = 'logs/url_unsubscriber.log'
logging.basicConfig(filename=LOG_FILENAME, level=logging.DEBUG)
date = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

def processUrl(request):
	request_url = request.build_absolute_uri()
	urls = re.search('\/\?url\=(.*)', request_url).group(1)
	logging.info(' ' + date + ' ' + urls + ' ' + 'URL_Parsed:processUrl')
	if urls != '':
		logging.debug(' ' + date + ' ' + urls + ' ' + 'URL_Not_empty:processUrl')
		extractUrl(urls)
		automateUrl(urls)
		return render(request, 'unregister/index.php')
	else:
		logging.info(' ' + date + ' ' + urls + ' ' + 'URL_Empty:processUrl')
		urls = 'ERROR IN REQUEST'
		return HttpResponse(urls)
	
def extractUrl(urls):
        page = requests.get(urls)
        if page.status_code != 200:
		logging.info(' ' + date + ' ' + urls + ' ' + 'URL_Not_exist:extractUrl')
                return 0
        else:
		logging.debug(' ' + date + ' ' + urls + ' ' + 'URL_Extractd:extractUrl')
                soup = BeautifulSoup(page.content, 'html.parser')
                print(soup.prettify())
                list(soup.children)

def automateUrl(urls):
        process = 1
	browser = webdriver.Firefox()
        browser.get(urls)
	logging.info(' ' + date + ' ' + urls + ' ' + 'URL_Opened:automateUrl')
        time.sleep(2)

	try:
	        browser.find_elements_by_xpath("//*[contains(text(), 'Thank you')]")
		processed = 0
	except NoSuchElementException:
        	pass

	try:
        	browser.find_element_by_xpath("//input[@type='submit']").click()
	        processed = 0
	except NoSuchElementException:
        	pass

   	try:
        	browser.find_element_by_xpath("//button[@type='submit']").click()
	        processed = 0
	except NoSuchElementException:
        	pass

	try:
        	browser.find_element_by_xpath("//input[@type='button']").click()
	        processed = 0
	except NoSuchElementException:
        	pass

	try:
        	browser.switch_to_alert().accept()
	        processed = 0
	except NoAlertPresentException:
        	pass
	time.sleep(2)
        browser.quit()
	logging.info(' ' + date + ' ' + urls + ' ' + 'Automation_Successful:automateUrl')
